package tienda;
import java.io.IOException;

public class Main {

	public static void main(String[] args) {

		try {
			
			//Creo la tienda y escribo los productos en disco.
			System.out.println("La tienda online Jarmazon comienza con sus ofertas del Black Friday.\n");
			JarmazonStore store=new JarmazonStore();
			System.out.println(store);
			store.escribirFichero();
			
			//Lanzo a los procesos hijo que ser�n compradores
			for(byte i=0;i<10;i++) {
				ProcessBuilder pb=new ProcessBuilder("java","-jar","../CompradorCompulsivo/dist/comprador.jar",i+"");
				pb.inheritIO();
					pb.start();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
