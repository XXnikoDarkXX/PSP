package tienda;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Clase que gestiona el Stock de la Jarmazon Store, indicando en el fichero ../jarmazonStore.txt los productos que tiene en cada momento
 * @author Miguel P�ramos
 *
 */
public class JarmazonStore {
	private HashMap<String,byte[]> productos; //La clave es el nombre del producto, el array del valor siempre tiene dos, y solo dos posiciones. La primera, el precio del producto. La segunda, la cantidad que hay en Stock en la tienda.

	/**
	 * Constructor por defecto. Inicializa la store con unos productos prefijados.
	 */
	public JarmazonStore() {
		productos=new HashMap<String,byte[]>();
		productos.put("Radiador", new byte[]{20,2});
		productos.put("Coj�n", new byte[]{5,2});
		productos.put("L�mpara", new byte[]{7,1});
	}
	
	
	/**
	 * Construye una Store a partir de una lista de productos ya existentes.
	 * @param ruta
	 * @throws FileNotFoundException 
	 */
	public JarmazonStore(String ruta) throws FileNotFoundException {
		try {
			productos=new HashMap<String,byte[]>();
			BufferedReader br=new BufferedReader(new FileReader(ruta));
			br.readLine(); //Leo la l�nea JarmazonStore
			br.readLine(); // Leo la l�nea de guiones -----
			String producto=br.readLine();
			while(producto!=null) {
				String[] partes=producto.split(" ");
				if(partes.length>1) {
					byte[] precioStock=new byte[2];
					precioStock[0]=Byte.parseByte(partes[1].substring(0, partes.length - 3));
					precioStock[1]=Byte.parseByte(partes[2]);
					productos.put(partes[0], precioStock);
				}
				producto=br.readLine();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //Quito la l�nea JarmazonStore;
	}

	
	/**
	 * toString devuelve el Stock de la Jarmazon Store en el formato que tendr� el archivo ../jarmazonStore.txt.
	 * @return String detallando el stock de la tienda.
	 */
	@Override
	public String toString() {
		String res="JarmazonStore\n"
			+  "-------------\n";
		Iterator it=productos.keySet().iterator();
		while(it.hasNext()) {
			String nombreProducto=(String)it.next();
			res+=nombreProducto+" "+productos.get(nombreProducto)[0]+"� "+productos.get(nombreProducto)[1]+" unidades.\n";
		}
		return res+"\n";
	}
	
	/**
	 * escribe en ../jarmazonStore.txt todos los contenidos de la store, tal y como se imprimen con toString.
	 */
	public void escribirFichero()  {
		try {
			FileWriter fw=new FileWriter("../jarmazonStore.txt");
			fw.write(this.toString());
			fw.flush();
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	/**
	 * Funci�n que resta una unidad a un producto de la store, e indica si queda stock.
	 * Pre-requisito: nombreProducto debe existir dentro de los productos actuales de la Store.
	 * @param nombreProducto nombre del producto al que se va a restar una unidad.
	 * @return boolean indicando si se pudo restar la unidad  o no.
	 */
	public boolean restarUnidad(String nombreProducto) {
		productos.get(nombreProducto)[1]--;
		escribirFichero();
		return (productos.get(nombreProducto)[1])>=0;
	}
	
	
	/**
	 * devuelve en un array los productos disponibles en la tienda en el momento actual
	 * @return array con todos los productos disponibles en la tienda.
	 */
	public String[] productosDisponibles() {
		Iterator it=productos.keySet().iterator();
		ArrayList<String> productosEnVenta=new ArrayList<String>();
		while(it.hasNext()) {
			String actual=(String)it.next();
			if(productos.get(actual)[1]>0) {
				productosEnVenta.add(actual);
			}
		}
		return productosEnVenta.stream().toArray(String[]::new);
	}
	
	
	
	
}
