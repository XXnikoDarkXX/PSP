package comprador;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class Main {

	public static void main(String[] args) {
		try {
			//Inicializo args[0] en el caso en que inicie el programa sin un padre
			if(args.length==0) {
				args=new String[1];
				args[0]="de prueba";
			}
			
			//Inicializaci�n de variables
			ArrayList<String> articulosComprados=new ArrayList<String>();
			
			JarmazonStore store=new JarmazonStore("../jarmazonStore.txt");
			String[] productosDisponibles=new String[1];
			Random r=new Random();
			
			while(productosDisponibles.length!=0) {

					//Recargo la tienda y los productos disponibles
					store=new JarmazonStore("../jarmazonStore.txt");
					productosDisponibles=store.productosDisponibles();
					if(productosDisponibles.length>0) {
						String articuloAComprar=productosDisponibles[r.nextInt(productosDisponibles.length)];
						System.out.println("Comprador "+args[0]+": iniciando la compra de "+articuloAComprar);
						Thread.sleep(1000);
						
						
						if(store.restarUnidad(articuloAComprar)) {
							System.out.println("Comprador "+args[0]+": Comprado "+articuloAComprar);
							articulosComprados.add(articuloAComprar);
						}else {
							System.out.println("Comprador "+args[0]+": Imposible realizar la compra");
						}
					}else {
						System.out.println("Comprador "+args[0]+": Imposible realizar la compra");
					}
					
					
			}
			
			//Informo de lo que he podido comprar.
			Thread.sleep(2000);
			System.out.print("Comprador "+args[0]+": Termin� de comprar. Ha comprado: "+articulosComprados+"\n");
	
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
