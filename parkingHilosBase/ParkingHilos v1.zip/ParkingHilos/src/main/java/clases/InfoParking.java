/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author mparamos
 */
public class InfoParking {
    private int nPlazas;

    public InfoParking(int nPlazas) {
        this.nPlazas = nPlazas;
    }

    public int getnPlazas() {
        return nPlazas;
    }

    public void añadirPlaza(){
        nPlazas++;
    }
    
    public void restarPlaza(){
        nPlazas--;
    }
    
    
    
}
